#ifndef __PCIEFD_SF2_H__
#define __PCIEFD_SF2_H__

#include "pciefd_hwif.h"

extern const struct pciefd_driver_data PCIEFD_DRIVER_DATA_SF2;
#endif /* __PCIEFD_SF2_H__ */
