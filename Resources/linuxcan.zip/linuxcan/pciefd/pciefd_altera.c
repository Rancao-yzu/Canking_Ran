/**
 * Kvaser Altera hardware layer
 */

#include "pciefd_altera.h"
#include "altera_int.h"
#include "debugprint.h"
#include "spi_flash.h"
#include "pciefd_hwif.h"
#include "VCanOsIf.h"

/* clang-format off */
#define ALL_ALTERA_PCI_INTERRUPTS \
    (ALTERA_PCI_IRQ_CAN_TX(0)     \
    | ALTERA_PCI_IRQ_CAN_TX(1)    \
    | ALTERA_PCI_IRQ_CAN_TX(2)    \
    | ALTERA_PCI_IRQ_CAN_TX(3)    \
    | ALTERA_PCI_IRQ_CAN_RX0)
/* clang-format on */

// Main block offsets (bytes)
#define OFFSET_TECH 0x00000000
#define OFFSET_KCAN 0x00010000
#define OFFSET_MISC 0x0001f800

// KCAN sub block offsets (bytes)
#define OFFSET_KCAN_META (OFFSET_KCAN + 0x0f020)
#define OFFSET_KCAN_TIME (OFFSET_KCAN + 0x0f040)

#define OFFSET_KCAN_RX_DATA (OFFSET_KCAN + 0x0f200)
#define OFFSET_KCAN_RX_CTRL (OFFSET_KCAN + 0x0f400)
#define OFFSET_KCAN_TX0     (OFFSET_KCAN + 0x00000)
#define OFFSET_KCAN_TX1     (OFFSET_KCAN + 0x01000)
#define OFFSET_KCAN_TX2     (OFFSET_KCAN + 0x02000)
#define OFFSET_KCAN_TX3     (OFFSET_KCAN + 0x03000)
#define CAN_CONTROLLER_SPAN (OFFSET_KCAN_TX1 - OFFSET_KCAN_TX0)

#define OFFSET_PCI_IRQ   (OFFSET_TECH + 0x00040)
#define OFFSET_SPI_FLASH (OFFSET_MISC)

// Avalon Address Translation Table Address Space Bit Encodings
enum {
    AV_ATT_ASBE_MS32 = 0, // 32-bit address (bits 63:32 are ignored)
    AV_ATT_ASBE_MS64 = 1 // 64 bit address
};

/* clang-format off */
const struct pciefd_irq_defines ALTERA_IRQ_DEFINES = {
    .kcan_rx0 = ALTERA_PCI_IRQ_CAN_RX0,
    .kcan_tx = {
        ALTERA_PCI_IRQ_CAN_TX(0),
        ALTERA_PCI_IRQ_CAN_TX(1),
        ALTERA_PCI_IRQ_CAN_TX(2),
        ALTERA_PCI_IRQ_CAN_TX(3)
    },
};

static void altera_pci_irq_set(VCanCardData *vCard, bool enable)
{
    PciCanCardData *hCard = vCard->hwCardData;
    unsigned long irqFlags;

    // The card must be present!
    if (!vCard->cardPresent) {
        return;
    }

    spin_lock_irqsave(&hCard->lock, irqFlags);

    // Disable/enable interrupts from card
    if (enable) {
        DEBUGPRINT(3, "Enable interrupts:%08lx\n", ALL_ALTERA_PCI_INTERRUPTS);
        ALTERA_INT_set_enable_mask(hCard->io.interruptBase, ALL_ALTERA_PCI_INTERRUPTS);
    } else {
        DEBUGPRINT(3, "Disable interrupts\n");
        ALTERA_INT_set_enable_mask(hCard->io.interruptBase, 0);
    }

    spin_unlock_irqrestore(&hCard->lock, irqFlags);
}

static u32 altera_pci_irq_get(PciCanCardData *hCard)
{
    return ALTERA_INT_get_irq(hCard->io.interruptBase);
}

static int altera_setup_dma_address_translation(PciCanCardData *hCard, int pos, dmaCtxBuffer_t *bufferCtx)
{
  // Every table entry is 64 bits, two table entries are used for each channel.
  unsigned int tabEntryOffset = 0x1000+pos*8;

#ifdef KV_PCIEFD_DMA_64BIT
  DEBUGPRINT(3,"KV_PCIEFD_DMA_64BIT\n");

  if(hCard->useDmaAddr64)
    {
      DEBUGPRINT(3,"useDmaAddr64\n");

      iowrite32( (uint32_t)(bufferCtx->address | AV_ATT_ASBE_MS64),
                 SUM(hCard->io.pcieBar0Base, tabEntryOffset) );

      iowrite32( (uint32_t)(bufferCtx->address >> 32),
                 SUM(hCard->io.pcieBar0Base, tabEntryOffset+4) );
    }
  else
    {
#endif /* KV_PCIEFD_DMA_64BIT */
      iowrite32( (uint32_t)(bufferCtx->address | AV_ATT_ASBE_MS32),
                 SUM(hCard->io.pcieBar0Base, tabEntryOffset) );
      iowrite32(0, SUM(hCard->io.pcieBar0Base, tabEntryOffset+4) );

#ifdef KV_PCIEFD_DMA_64BIT
    }
#endif /* KV_PCIEFD_DMA_64BIT */

  return VCAN_STAT_OK;
}

const struct pciefd_card_ops ALTERA_CARD_OPS = {
    .setup_dma_address_translation = &altera_setup_dma_address_translation,
    .firmware_upgrade_trigger_update = NULL,
    .pci_irq_set = &altera_pci_irq_set,
    .pci_irq_get = &altera_pci_irq_get,
};

const struct pciefd_driver_data PCIEFD_DRIVER_DATA_ALTERA = {
    .ops = &ALTERA_CARD_OPS,
    .spi_ops = &SPI_FLASH_altera_ops,
    .irq_def = &ALTERA_IRQ_DEFINES,
    .offsets = {
        .tech = {
            .spi = OFFSET_SPI_FLASH,
            .interrupt = OFFSET_PCI_IRQ,
        },
        .kcan = {
            .meta = OFFSET_KCAN_META,
            .time = OFFSET_KCAN_TIME,
            .interrupt = 0,
            .rx_data = OFFSET_KCAN_RX_DATA,
            .rx_ctrl = OFFSET_KCAN_RX_CTRL,
            .tx0 = OFFSET_KCAN_TX0,
            .tx1 = OFFSET_KCAN_TX1,
            .tx2 = OFFSET_KCAN_TX2,
            .tx3 = OFFSET_KCAN_TX3,
            .controller_span = CAN_CONTROLLER_SPAN,
        },
    },
    .hw_const = {
        .supported_fpga_major = 2,
    },
};
