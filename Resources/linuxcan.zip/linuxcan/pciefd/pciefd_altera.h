#ifndef __PCIEFD_ALTERA_H__
#define __PCIEFD_ALTERA_H__

#include "pciefd_hwif.h"

extern const struct pciefd_driver_data PCIEFD_DRIVER_DATA_ALTERA;
#endif /* __PCIEFD_ALTERA_H__ */
