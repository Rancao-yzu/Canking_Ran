/**
 * Kvaser Smartfusion2 hardware layer
 */

#include "pciefd_sf2.h"
#include "debugprint.h"
#include "kcan_int.h"
#include "spi_flash.h"
#include "pciefd_hwif.h"
#include "VCanOsIf.h"
#include <linux/delay.h>
#include <linux/interrupt.h>

#if !(PCIEFD_USE_DMA)
#error DMA is required (PCIEFD_USE_DMA=1), FIFO mode does not work on Smartfusion2 devices!
#endif /* PCIEFD_USE_DMA */

#define SF2_GPIO_PIN_TRIG_UPDATE 0

/* clang-format off */
#define ALL_KCAN_INTERRUPTS \
    (KCAN_INT_IRQ_TX(0)     \
    | KCAN_INT_IRQ_TX(1)    \
    | KCAN_INT_IRQ_TX(2)    \
    | KCAN_INT_IRQ_TX(3)    \
    | KCAN_INT_IRQ_RX0)
/* clang-format on */

// Main block offsets (bytes)
#define OFFSET_TECH 0x00000000
#define OFFSET_KCAN 0x00100000
#define OFFSET_MISC 0x00200000

// Smartfusion2 peripherals
#define SF2_SPI0_BASE    0x00001000u
#define SF2_GPIO_BASE    0x00013000u
#define SF2_SERDES0_BASE 0x00028000u
#define OFFSET_SF2_AHB   OFFSET_TECH

#define OFFSET_SPI     (OFFSET_SF2_AHB + SF2_SPI0_BASE)
#define OFFSET_GPIO    (OFFSET_SF2_AHB + SF2_GPIO_BASE)
#define OFFSET_SERDES0 (OFFSET_SF2_AHB + SF2_SERDES0_BASE)

// KCAN sub block offsets (bytes)
#define OFFSET_KCAN_META (OFFSET_KCAN + 0x00000)
#define OFFSET_KCAN_TIME (OFFSET_KCAN + 0x01000)
#define OFFSET_KCAN_INTR (OFFSET_KCAN + 0x02000)
#define OFFSET_KCAN_RX_DATA \
    (OFFSET_KCAN + 0x20000 + 0x4) // +0x4 workaround for broken SERDES 64-bit to 32-bit support
#define OFFSET_KCAN_RX_CTRL (OFFSET_KCAN + 0x21000)
#define OFFSET_KCAN_TX0     (OFFSET_KCAN + 0x40000)
#define OFFSET_KCAN_TX1     (OFFSET_KCAN + 0x42000)
#define OFFSET_KCAN_TX2     (OFFSET_KCAN + 0x44000)
#define OFFSET_KCAN_TX3     (OFFSET_KCAN + 0x46000)
#define CAN_CONTROLLER_SPAN (OFFSET_KCAN_TX1 - OFFSET_KCAN_TX0)

const struct pciefd_irq_defines SF2_IRQ_DEFINES = {
    .kcan_rx0 = KCAN_INT_IRQ_RX0,
    .kcan_tx = { KCAN_INT_IRQ_TX(0), KCAN_INT_IRQ_TX(1), KCAN_INT_IRQ_TX(2), KCAN_INT_IRQ_TX(3) },
};
//======================================================================
//  Enable/disable all PCI interrupts on card
//======================================================================
static void sf2_pci_irq_set(VCanCardData *vCard, bool enable)
{
    PciCanCardData *hCard = vCard->hwCardData;
    unsigned long irqFlags;

    // The card must be present!
    if (!vCard->cardPresent) {
        return;
    }

    spin_lock_irqsave(&hCard->lock, irqFlags);

    // Disable/enable interrupts from card
    if (enable) {
        DEBUGPRINT(3, "Enable interrupts:%08lx\n", ALL_KCAN_INTERRUPTS);
        KCAN_INT_set_enable_mask(hCard->io.kcan.kcanIntBase, ALL_KCAN_INTERRUPTS);
    } else {
        DEBUGPRINT(3, "Disable interrupts\n");
        KCAN_INT_set_enable_mask(hCard->io.kcan.kcanIntBase, 0U);
    }

    spin_unlock_irqrestore(&hCard->lock, irqFlags);
}

static u32 sf2_pci_irq_get(PciCanCardData *hCard)
{
    if (unlikely(hCard->ongoing_firmware_upgrade)) {
        return 0;
    } else {
        return KCAN_INT_get_irq(hCard->io.kcan.kcanIntBase);
    }
}

#define SF2_SERDES_PCIE_AXI_SLAVE_WINDOWx_2(x) (OFFSET_SERDES0 + 0x10 * (x) + 0x0c8)
#define SF2_SERDES_PCIE_AXI_SLAVE_WINDOWx_3(x) (OFFSET_SERDES0 + 0x10 * (x) + 0x0cc)
static int sf2_setup_dma_address_translation(PciCanCardData *hCard, int pos,
                                             dmaCtxBuffer_t *bufferCtx)
{
    u32 lsb;
    u32 msb;

    lsb = (u32)(bufferCtx->address & 0xfffff000);
#ifdef KV_PCIEFD_DMA_64BIT
    DEBUGPRINT(3, "KV_PCIEFD_DMA_64BIT\n");
    if (hCard->useDmaAddr64) {
        DEBUGPRINT(3, "usedmaaddr64 = 1\n");
        msb = (u32)(bufferCtx->address >> 32);
    } else {
#endif /* KV_PCIEFD_DMA_64BIT */
        DEBUGPRINT(3, "usedmaaddr64 = 0\n");
        msb = 0x0;
#ifdef KV_PCIEFD_DMA_64BIT
    }
#endif /* KV_PCIEFD_DMA_64BIT */
    DEBUGPRINT(4, "LSB = 0x%08x\tMSB = 0x%08x\n", lsb, msb);
    iowrite32(lsb, SUM(hCard->io.pcieBar0Base, SF2_SERDES_PCIE_AXI_SLAVE_WINDOWx_2(pos)));
    iowrite32(msb, SUM(hCard->io.pcieBar0Base, SF2_SERDES_PCIE_AXI_SLAVE_WINDOWx_3(pos)));

    return VCAN_STAT_OK;
}

#define SF2_GPIO_OUT (OFFSET_GPIO + 0x0088)
static int sf2_firmware_upgrade_trigger_update(VCanCardData *vCard)
{
    PciCanCardData *hCard = vCard->hwCardData;
    u32 gpio_out;
    int i;

    vCard->card_flags |= DEVHND_CARD_REFUSE_TO_USE_CAN;
    sf2_pci_irq_set(vCard, false);
    hCard->ongoing_firmware_upgrade = true;
    gpio_out = ioread32(SUM(hCard->io.pcieBar0Base, SF2_GPIO_OUT));
    gpio_out |= BIT(SF2_GPIO_PIN_TRIG_UPDATE);
    iowrite32(gpio_out, SUM(hCard->io.pcieBar0Base, SF2_GPIO_OUT));
    DEBUGPRINT(2, "Update triggered by setting GPIO pin %u.\n", SF2_GPIO_PIN_TRIG_UPDATE);
    /* Wait 50 seconds for the Smartfusion2 SoC to re-program and restart itself */
    for (i = 0; i < 10; i++) {
        /* Avoid long sleep to prevent "soft lockup" kernel warning */
        msleep(5 * 1000);
    }

    return VCAN_STAT_OK;
}

const struct pciefd_card_ops SF2_CARD_OPS = {
    .setup_dma_address_translation = &sf2_setup_dma_address_translation,
    .firmware_upgrade_trigger_update = &sf2_firmware_upgrade_trigger_update,
    .pci_irq_set = &sf2_pci_irq_set,
    .pci_irq_get = &sf2_pci_irq_get,
};

const struct pciefd_driver_data PCIEFD_DRIVER_DATA_SF2 = {
    .ops = &SF2_CARD_OPS,
    .spi_ops = &SPI_FLASH_sf2_ops,
    .irq_def = &SF2_IRQ_DEFINES,
    .offsets = {
        .tech = {
            .spi = OFFSET_SPI,
        },
        .kcan = {
            .meta = OFFSET_KCAN_META,
            .time = OFFSET_KCAN_TIME,
            .interrupt = OFFSET_KCAN_INTR,
            .rx_data = OFFSET_KCAN_RX_DATA,
            .rx_ctrl = OFFSET_KCAN_RX_CTRL,
            .tx0 = OFFSET_KCAN_TX0,
            .tx1 = OFFSET_KCAN_TX1,
            .tx2 = OFFSET_KCAN_TX2,
            .tx3 = OFFSET_KCAN_TX3,
            .controller_span = CAN_CONTROLLER_SPAN,
        },
    },
    .hw_const = {
        .supported_fpga_major = 1,
    },
};
