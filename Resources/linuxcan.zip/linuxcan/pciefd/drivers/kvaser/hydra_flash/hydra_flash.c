/*
**             Copyright 2023 by Kvaser AB, Molndal, Sweden
**                         http://www.kvaser.com
**
** This software is dual licensed under the following two licenses:
** BSD-new and GPLv2. You may use either one. See the included
** COPYING file for details.
**
** License: BSD-new
** ==============================================================================
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**     * Redistributions of source code must retain the above copyright
**       notice, this list of conditions and the following disclaimer.
**     * Redistributions in binary form must reproduce the above copyright
**       notice, this list of conditions and the following disclaimer in the
**       documentation and/or other materials provided with the distribution.
**     * Neither the name of the <organization> nor the
**       names of its contributors may be used to endorse or promote products
**       derived from this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
** BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
** IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
**
** License: GPLv2
** ==============================================================================
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
**
**
** IMPORTANT NOTICE:
** ==============================================================================
** This source code is made available for free, as an open license, by Kvaser AB,
** for use with its applications. Kvaser AB does not accept any liability
** whatsoever for any third party patent or other immaterial property rights
** violations that may result from any usage of this source code, regardless of
** the combination of source code and various applications that it can be used
** in, or with.
**
** -----------------------------------------------------------------------------
*/
#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/string.h>
#include <linux/crc32.h>
#include <linux/slab.h>
#include <linux/ktime.h>
#include <linux/pci.h>
#include "util.h"
#include "debugprint.h"
#include "VCanOsIf.h"
#include "pciefd_hwif.h"
#include "spi_flash.h"
#include "kcan_ioctl_flash.h"
#include "hydra_imgheader.h"
#include "pciefd_config.h"
#include "hydra_flash.h"
#include "led.h"

#define SIMULATE_WRITE 0

#if SIMULATE_WRITE
#pragma message __FILE__ " is compiled in write simulation mode."
#endif

#define FLASH_SIZE           (2 * 1024 * 1024U) // 2 MiB
#define PARAM_IMAGE_SIZE_MAX (64 * 1024U) // 64 kiB (partially used)
#define PARAM_IMAGE_OFFSET   (FLASH_SIZE - PARAM_IMAGE_SIZE_MAX) // 0x001F0000 @32 MiB

#define FPGA_IMAGE_SIZE_MAX (FLASH_SIZE - PARAM_IMAGE_SIZE_MAX) // All but the last 64 kiB
#define FPGA_IMAGE_OFFSET   0U

#define MAX_PARAM_NUM 256
#define PARAM_MAGIC   0xCAFEF00D
#define PARAM_SYS_VER 1

#define PARAM_SERIAL_NUMBER        124
#define PARAM_MANUFACTURING_DATE   125
#define PARAM_HW_REVISION          127
#define PARAM_HW_TYPE              128
#define PARAM_EAN_NUMBER           129
#define PARAM_NUMBER_CHANNELS      130
#define PARAM_CHANNEL_A_TRANS_TYPE 132
#define PARAM_CHANNEL_B_TRANS_TYPE 133
#define PARAM_HW_DESCRIPTION_0     134
#define PARAM_HW_DESCRIPTION_1     135
#define PARAM_HW_DESCRIPTION_2     136
#define PARAM_CHANNEL_C_TRANS_TYPE 137
#define PARAM_CHANNEL_D_TRANS_TYPE 138
#define PARAM_EAN_NUMBER_PRODUCT   143
#define PARAM_MAX_BITRATE          148

// Parameter length, in bytes.
#define PARAM_SERIAL_NUMBER_LEN       4
#define PARAM_MANUFACTURING_DATE_LEN  4
#define PARAM_HW_REVISION_LEN         1
#define PARAM_HW_TYPE_LEN             1
#define PARAM_EAN_NUMBER_LEN          8
#define PARAM_NUMBER_CHANNELS_LEN     1
#define PARAM_CHANNEL_TRANS_TYPE_LEN  1
#define PARAM_HW_DESCRIPTION_PART_LEN 8
#define PARAM_EAN_NUMBER_PRODUCT_LEN  8
#define PARAM_MAX_BITRATE_LEN         4

#define PARAM_USER_FIRST               (1)
#define CHANNEL_NAME_NBR_OF_PARAMS     (1)
#define CHANNEL_NAME_PARAM_INDEX_FIRST (PARAM_USER_FIRST + 1)

typedef struct {
    u32 magic; //PARAM_MAGIC indicate used
    u32 number;
    u32 len;
    u8 data[HYDRA_FLASH_PARAM_MAX_SIZE];
} kcc_param_t;

typedef struct {
    u32 version;
    u32 magic;
    u32 crc;
    kcc_param_t param[MAX_PARAM_NUM];
} kcc_param_image_t;

static_assert(sizeof(kcc_param_image_t) <= PARAM_IMAGE_SIZE_MAX);

#define ASSERT_ARG_VCAN(cond)               \
    do {                                    \
        if (!(cond))                        \
            return VCAN_STAT_BAD_PARAMETER; \
    } while (0)

#define ASSERT_ARG_FW(cond)                    \
    do {                                       \
        if (!(cond))                           \
            return FIRMWARE_ERROR_INVALID_ARG; \
    } while (0)

//======================================================================
//  Verify parameter image
//======================================================================
static int verify_param_image(kcc_param_image_t *img)
{
    u32 crc32;

    ASSERT_ARG_VCAN(img != NULL);

    if ((img->version != PARAM_SYS_VER) || (img->magic != PARAM_MAGIC)) {
        DEBUGPRINT(1, "ERROR: %s version or magic error\n", __func__);
        DEBUGPRINT(1, "       version: got %d, expected %d\n", img->version, PARAM_SYS_VER);
        DEBUGPRINT(1, "       magic:   got %x, expected %x\n", img->magic, PARAM_MAGIC);
        return -6;
    }

    crc32 = calculateCRC32(img->param, sizeof(img->param));
    if (img->crc != crc32) {
        DEBUGPRINT(1, "ERROR: %s incorrect crc should be 0x%08x, is 0x%08x\n", __func__, img->crc,
                   crc32);
        return -6;
    }

    return VCAN_STAT_OK;
}

//======================================================================
//  Read a parameter
//======================================================================
static int read_param(const kcc_param_image_t *img, uint p_num, void *p_data, uint p_len)
{
    ASSERT_ARG_VCAN(img != NULL);
    ASSERT_ARG_VCAN(p_num < MAX_PARAM_NUM);
    ASSERT_ARG_VCAN(p_data != NULL);
    ASSERT_ARG_VCAN(p_len <= HYDRA_FLASH_PARAM_MAX_SIZE);

    if (img->param[p_num].magic != PARAM_MAGIC) {
        DEBUGPRINT(2, "Error: %s param no=%u param magic=%u, actual_param magic=%u\n", __func__,
                   p_num, img->param[p_num].magic, PARAM_MAGIC);
        return VCAN_STAT_FAIL;
    }

    if (p_len != img->param[p_num].len) {
        DEBUGPRINT(1, "Error: %s param no.=%u param len=%u, actual_param len=%u\n", __func__, p_num,
                   p_len, img->param[p_num].len);
        return VCAN_STAT_FAIL;
    }

    memcpy(p_data, img->param[p_num].data, p_len);
    return VCAN_STAT_OK;
}

//======================================================================
// Read parameters from serial flash memory
//======================================================================
int HYDRA_FLASH_read_params(VCanCardData *vCard)
{
    PciCanCardData *hCard;
    kcc_param_image_t *img = NULL;
    unsigned int i;
    int status;
    u32 duration_ms;

    ASSERT_ARG_VCAN(vCard != NULL);
    hCard = vCard->hwCardData;
    hCard->spif.time = ktime_get();

    img = kzalloc(sizeof(kcc_param_image_t), GFP_KERNEL);
    if (img == NULL) {
        DEBUGPRINT(1, "Failed to allocate memory.\n");
        return VCAN_STAT_NO_MEMORY;
    }

    status = SPI_FLASH_read(&hCard->spif, PARAM_IMAGE_OFFSET, (u8 *)img, sizeof(kcc_param_image_t));

    if (status != SPI_FLASH_STATUS_SUCCESS) {
        DEBUGPRINT(1, "Error %d when reading parameter image.\n", status);
        goto error_exit;
    }

    status = verify_param_image(img);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    status = read_param(img, PARAM_EAN_NUMBER, vCard->ean, PARAM_EAN_NUMBER_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    status = read_param(img, PARAM_HW_REVISION, &vCard->hwRevisionMajor, PARAM_HW_REVISION_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    status = read_param(img, PARAM_SERIAL_NUMBER, &vCard->serialNumber, PARAM_SERIAL_NUMBER_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    status = read_param(img, PARAM_HW_TYPE, &vCard->hw_type, PARAM_HW_TYPE_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    status = read_param(img, PARAM_MAX_BITRATE, &vCard->default_max_bitrate, PARAM_MAX_BITRATE_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    vCard->current_max_bitrate = vCard->default_max_bitrate;
#ifdef FPGA_META_OVERRIDES_FLASH
    pr_warn("INFO: No. of channels was NOT read from flash!\n");
#else
    status = read_param(img, PARAM_NUMBER_CHANNELS, &vCard->nrChannels, PARAM_NUMBER_CHANNELS_LEN);
    if (status != VCAN_STAT_OK)
        goto error_exit;

    vCard->nrChannels = min(vCard->nrChannels, MAX_CARD_CHANNELS);
#endif
    if (vCard->nrChannels > 0) {
        status = read_param(img, PARAM_CHANNEL_A_TRANS_TYPE, &vCard->chanData[0]->transType,
                            PARAM_CHANNEL_TRANS_TYPE_LEN);
        if (status != VCAN_STAT_OK)
            goto error_exit;
    }
    if (vCard->nrChannels > 1) {
        status = read_param(img, PARAM_CHANNEL_B_TRANS_TYPE, &vCard->chanData[1]->transType,
                            PARAM_CHANNEL_TRANS_TYPE_LEN);
        if (status != VCAN_STAT_OK)
            goto error_exit;
    }
    if (vCard->nrChannels > 2) {
        status = read_param(img, PARAM_CHANNEL_C_TRANS_TYPE, &vCard->chanData[2]->transType,
                            PARAM_CHANNEL_TRANS_TYPE_LEN);
        if (status != VCAN_STAT_OK)
            goto error_exit;
    }
    if (vCard->nrChannels > 3) {
        status = read_param(img, PARAM_CHANNEL_D_TRANS_TYPE, &vCard->chanData[3]->transType,
                            PARAM_CHANNEL_TRANS_TYPE_LEN);
        if (status != VCAN_STAT_OK)
            goto error_exit;
    }
    for (i = 0; i < MAX_CARD_CHANNELS; i++) {
        // These are optional, hence we don't check the return code
        read_param(img, CHANNEL_NAME_PARAM_INDEX_FIRST + i, hCard->cust_channel_name[i],
                   sizeof(hCard->cust_channel_name[i]));
    }
    kfree(img);
    duration_ms = ktime_ms_delta(ktime_get(), hCard->spif.time);
    DEBUGPRINT(3, "Reading parameters took %u.%03u seconds.\n", duration_ms / 1000,
               duration_ms % 1000);
    return VCAN_STAT_OK;

error_exit:
    if (img != NULL)
        kfree(img);
    return VCAN_STAT_FAIL;
}


//======================================================================
//  Calculate firmware image checksum
//======================================================================
static u32 calc_fw_checksum(u8 *buffer, u32 size)
{
    return crc32(0xffffffff, buffer, size) ^ 0xffffffff;
}

//======================================================================
//  Verify firmware image EAN
//======================================================================
static int verify_fw_ean(const VCanCardData *vCard, const HydraImgHeader *sysHeader)
{
    u32 ean_hi = *(u32 *)&(vCard->ean[4]);
    u32 ean_lo = *(u32 *)&(vCard->ean[0]);

    if (ean_hi != sysHeader->eanHi)
        return -1;
    if (ean_lo != sysHeader->eanLo)
        return -1;
    return 0;
}

//======================================================================
//  Write firmware image
//======================================================================
static int write_fw_image(struct spi_flash *spif, u32 addr, const u8 *buf, u32 num_bytes)
{
    int status;

    ASSERT_ARG_FW(spif != NULL);
    ASSERT_ARG_FW(buf != NULL);

    if ((addr + num_bytes) > (FPGA_IMAGE_OFFSET + FPGA_IMAGE_SIZE_MAX)) {
        DEBUGPRINT(1, "%s FPGA image size too big, aborting\n", __func__);
        return FIRMWARE_ERROR_INVALID_ARG;
    }

#if !SIMULATE_WRITE
    status = SPI_FLASH_erase_multi_64K(spif, addr, num_bytes, 5000);
    if (status != SPI_FLASH_STATUS_SUCCESS) {
        DEBUGPRINT(1, "%s Error, flash erase failed with %d, aborting", __func__, status);
        return FIRMWARE_ERROR_FLASH_FAILED;
    }

    status = SPI_FLASH_write_multi_page(spif, addr, buf, num_bytes);
    if (status != SPI_FLASH_STATUS_SUCCESS) {
        DEBUGPRINT(1, "%s Error, page write failed with %d, aborting.", __func__, status);
        return FIRMWARE_ERROR_FLASH_FAILED;
    }
#else
    NOT_USED(status);
    DEBUGPRINT(1, "Simulating erase between 0x%08X - 0x%08X\n", addr,
               addr + (DIV_ROUND_UP(num_bytes, (64 * 1024U)) * (64 * 1024U)));
    DEBUGPRINT(1, "Simulating write of %u bytes at 0x%08X - 0x%08X\n", num_bytes, addr,
               addr + num_bytes);
#endif

    return FIRMWARE_STATUS_OK;
}

//======================================================================
//  Verify firmware image
//======================================================================
static int verify_fw_image(struct spi_flash *spif, u32 addr, const u8 *buf, u32 num_bytes)
{
#if !SIMULATE_WRITE
    int status;

    status = SPI_FLASH_compare(spif, addr, buf, num_bytes);
    if (status != SPI_FLASH_STATUS_SUCCESS) {
        DEBUGPRINT(1, "Warning: Image does NOT match current.\n");
        return FIRMWARE_ERROR_VERIFY_DIFF;
    }
#else
    NOT_USED(hCard);
    NOT_USED(addr);
    NOT_USED(buf);
    NOT_USED(num_bytes);
#endif
    DEBUGPRINT(2, "Image matches current.\n");
    return FIRMWARE_STATUS_OK;
}

//======================================================================
//  Trig reprogram of device
//======================================================================
static int trigger_update(VCanCardData *vCard)
{
    PciCanCardData *hCard = vCard->hwCardData;
    const struct pciefd_card_ops *card_ops = hCard->driver_data->ops;
    int status = FIRMWARE_STATUS_OK;

#if !SIMULATE_WRITE
    // firmware_upgrade_trigger_update is optional, call if it is set
    if (card_ops->firmware_upgrade_trigger_update) {
        status = card_ops->firmware_upgrade_trigger_update(vCard);
    }
#endif

    return status;
}

//======================================================================
//  Write firmware image, then read it back and verify
//======================================================================
static int write_verify_fw_image(struct spi_flash *spif, u32 addr, const u8 *buf, u32 num_bytes)
{
    int status;

    status = write_fw_image(spif, addr, buf, num_bytes);
    if (status != FIRMWARE_STATUS_OK) {
        DEBUGPRINT(1, "Error: %s write failed: %d\n", __func__, status);
        return status;
    }

    status = verify_fw_image(spif, addr, buf, num_bytes);
    if (status != FIRMWARE_STATUS_OK) {
        DEBUGPRINT(1, "Error: %s compare failed\n", __func__);
    }

    return status;
}


//======================================================================
//  Do firmware update by processing IOCTL commands
//======================================================================
int HYDRA_FLASH_update_fw_ioctl(const VCanChanData *vChan, KCAN_FLASH_PROG *fp)
{
    VCanCardData *vCard = vChan->vCard;
    PciCanCardData *hCard = vCard->hwCardData;
    PciCanChanData *hChd = vChan->hwChanData;

    switch (fp->tag) {
    case FIRMWARE_DOWNLOAD_STARTUP:
        if (hCard->flashImage == NULL) {
            hCard->flashImage = kmalloc(FPGA_IMAGE_SIZE_MAX, GFP_KERNEL);
            if (hCard->flashImage == NULL) {
                DEBUGPRINT(1, "Error: kmalloc (FPGA_IMAGE_SIZE_MAX)\n");
                return VCAN_STAT_NO_MEMORY;
            }
        }
        memset(hCard->flashImage, 0xff, FPGA_IMAGE_SIZE_MAX);

        hCard->spif.dry_run = (bool)fp->x.setup.dryrun;
        fp->x.setup.flash_procedure_version = 0;
        fp->x.setup.buffer_size = KCAN_FLASH_DOWNLOAD_CHUNK;
        LED_ON(hChd->canControllerBase);
        break;

    case FIRMWARE_DOWNLOAD_WRITE:
        if (hCard->flashImage && ((fp->x.data.address + fp->x.data.len) < FPGA_IMAGE_SIZE_MAX)) {
            memcpy(hCard->flashImage + fp->x.data.address, fp->x.data.data, fp->x.data.len);
        } else {
            fp->status = FIRMWARE_ERROR_ADDR;
            goto error_exit;
        }
        break;

    case FIRMWARE_DOWNLOAD_COMMIT: {
        HydraImgHeader *sysHeader;
        int numberOfImages;
        int i;

        if (hCard->flashImage == NULL) {
            fp->status = FIRMWARE_ERROR_ADDR;
            return VCAN_STAT_FAIL;
        }

        sysHeader = (HydraImgHeader *)hCard->flashImage;
        /* validate image header */
        if (sysHeader->hdCrc !=
            calc_fw_checksum(hCard->flashImage, sizeof(HydraImgHeader) - sizeof(u32))) {
            fp->status = FIRMWARE_ERROR_BAD_CRC;
            goto error_exit;
        }

        /* validate image type */
        if (sysHeader->imgType != IMG_TYPE_SYSTEM_CONTAINER) {
            DEBUGPRINT(1, "Error: image type %d invalid\n", sysHeader->imgType);
            fp->status = FIRMWARE_ERROR_ADDR;
            goto error_exit;
        }

        /* ensure image matches current hardware */
        if (verify_fw_ean(vCard, sysHeader) != 0) {
            DEBUGPRINT(1, "Error: image EAN does not match device\n");
            fp->status = FIRMWARE_ERROR_FLASH_FAILED;
            goto error_exit;
        }

        numberOfImages = *(hCard->flashImage + sizeof(HydraImgHeader));
        DEBUGPRINT(3, "Nbr images %d\n", numberOfImages);

        for (i = 0; i < numberOfImages; i++) {
            /* validate full hydra image */
            if (calc_fw_checksum(hCard->flashImage + sizeof(HydraImgHeader),
                                 sysHeader->imgLength) == sysHeader->imgCrc) {
                ImageContainerInfo *imgInfo;
                HydraImgHeader *imgHeader;
                u8 *startAddr;

                imgInfo = (ImageContainerInfo *)(hCard->flashImage + sizeof(HydraImgHeader) + 4);
                imgHeader = (HydraImgHeader *)(hCard->flashImage + imgInfo[i].imgStartAddr);
                startAddr = hCard->flashImage + imgInfo[i].imgStartAddr + sizeof(HydraImgHeader);

                DEBUGPRINT(3, "Sys image validated. (V.%08x)\n", sysHeader->version);
                if (!hCard->spif.dry_run) {
                    fp->status = write_verify_fw_image(&hCard->spif, imgHeader->prgAddr, startAddr,
                                                       imgHeader->imgLength);
                    if (fp->status == FIRMWARE_STATUS_OK) {
                        if (i == numberOfImages - 1) {
                            fp->status = trigger_update(vCard);
                        }
                        DEBUGPRINT(3, "Flashing image %i of %i was completed with status %d.\n", i,
                                   numberOfImages, fp->status);
                    } else {
                        DEBUGPRINT(3, "Flashing image %i of %i failed with status %d, aborting.\n",
                                   i, numberOfImages, fp->status);
                        goto error_exit;
                    }
                } else {
                    DEBUGPRINT(3, "Dry-run  %i of %i.\n", i, numberOfImages);
                    verify_fw_image(&hCard->spif, imgHeader->prgAddr, startAddr,
                                    imgHeader->imgLength);
                    if (i == numberOfImages - 1) {
                        LED_OFF(hChd->canControllerBase);
                    }
                }
            } else {
                DEBUGPRINT(1, "Error: Image crc check failed. (V.%08x)\n", sysHeader->version);
                goto error_exit;
            }
        }
        break;
    }

    case FIRMWARE_DOWNLOAD_FINISH:
        if (hCard->flashImage) {
            DEBUGPRINT(3, "freeing image buffer\n");
            kfree(hCard->flashImage);
            hCard->flashImage = NULL;
        } else {
            fp->status = FIRMWARE_ERROR_ADDR;
            return VCAN_STAT_FAIL;
        }
        break;

    case FIRMWARE_DOWNLOAD_ERASE:
        /* not supported */
        break;

    default:
        DEBUGPRINT(1, "Error: %s, Unknown tag %d\n", __func__, fp->tag);
        goto error_exit;
    }

    return VCAN_STAT_OK;

error_exit:
    if (hCard->flashImage) {
        DEBUGPRINT(3, "freeing image buffer\n");
        kfree(hCard->flashImage);
        hCard->flashImage = NULL;
    }
    LED_OFF(hChd->canControllerBase);
    return VCAN_STAT_FAIL;
}

